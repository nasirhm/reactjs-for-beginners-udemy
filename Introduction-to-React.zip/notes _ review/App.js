import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <h1>Hi, this is my app!</h1>
        <p>I'm Victor. I'm good at ReactJS!</p>
      </div>
    );
  }
}

export default App;
